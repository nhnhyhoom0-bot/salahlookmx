#!/usr/bin/env python3
"""Create latest.json for xlop launcher updates.

Usage:
  python3 make_update_manifest.py xlop-launcher_1.2.0_all.deb \
      --url https://github.com/OWNER/REPO/releases/download/v1.2.0/xlop-launcher_1.2.0_all.deb \
      --notes "إصلاح مشاكل وإضافة ميزات"

Upload BOTH files (the .deb and latest.json) to the same release. Every installed launcher
that checks  https://github.com/OWNER/REPO/releases/latest/download/latest.json  will see it.
"""
import argparse
import hashlib
import json
import subprocess
import sys


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("deb")
    p.add_argument("--url", required=True, help="public download link of the .deb (https)")
    p.add_argument("--notes", default="", help="what's new; shown to the user")
    p.add_argument("--windows-url", default="", help="public https link of the Windows xlop-launcher.exe (optional)")
    p.add_argument("-o", "--output", default="latest.json")
    a = p.parse_args()
    if not a.url.startswith("https://"):
        sys.exit("error: --url must start with https://")

    def field(name):
        r = subprocess.run(["dpkg-deb", "-f", a.deb, name], capture_output=True, text=True)
        if r.returncode:
            sys.exit("error: %s is not a valid .deb (%s)" % (a.deb, r.stderr.strip()))
        return r.stdout.strip()

    if field("Package") != "xlop-launcher":
        sys.exit("error: this .deb is not the xlop-launcher package")
    data = open(a.deb, "rb").read()
    manifest = {"version": field("Version"), "url": a.url, "sha256": hashlib.sha256(data).hexdigest(),
                "size": len(data), "notes": a.notes}
    if a.windows_url:
        if not a.windows_url.startswith("https://"):
            sys.exit("error: --windows-url must start with https://")
        manifest["windows_url"] = a.windows_url
    with open(a.output, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    print("wrote %s  (version %s, %d bytes, sha256 %s…)" % (a.output, manifest["version"], len(data), manifest["sha256"][:12]))


if __name__ == "__main__":
    main()
