@echo off
rem Builds a STANDALONE xlop-launcher.exe (no Python needed on the target PC). Run on Windows.
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul || (echo Python is not installed. Get it from https://www.python.org/downloads/windows/ & pause & exit /b 1)
py -3 -m pip install --upgrade pip pyinstaller || (echo pip failed & pause & exit /b 1)
py -3 -m PyInstaller --noconfirm --clean --onefile --windowed --name xlop-launcher --icon xlop-launcher.ico --add-data "xlop-launcher.png;." --exclude-module xlop.gui --exclude-module gi run_xlop.py || (echo Build failed & pause & exit /b 1)
echo.
echo Done: dist\xlop-launcher.exe
pause
