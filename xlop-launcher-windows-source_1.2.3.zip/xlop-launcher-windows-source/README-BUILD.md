# بناء xlop-launcher.exe مستقل (لا يحتاج Python عند المستخدم)

ملف exe المستقل لا يُبنى إلا على Windows. نستعمل لذلك خدمة GitHub Actions المجانية، وهي تبنيه وتختبر الواجهة على Windows حقيقي.

## الخطوات (من المتصفح، بدون برامج)
1. فُكّ ضغط هذه الحزمة على جهازك.
2. افتح مستودعك على GitHub ← **Add file ← Upload files**.
3. اسحب **محتويات** المجلد المفكوك إلى الصفحة (يجب أن تشمل المجلدين `xlop` و`.github` والملفات `run_xlop.py` وغيرها)، ثم اضغط **Commit changes**.
4. افتح تبويب **Actions**. سيبدأ تلقائيًا تشغيل **Build Windows exe** (3 إلى 6 دقائق).
5. عند النجاح (علامة ✓ خضراء) افتح التشغيل ← قسم **Artifacts** ← نزّل `xlop-launcher-windows` وفيه `xlop-launcher.exe`.
6. إن ظهرت علامة ✗ حمراء: افتح الخطوة الفاشلة وانسخ النص الذي يظهر وأرسله لي.

## إصدار رسمي
أنشئ Release بوسم مثل `v1.2.3` فيُرفق `xlop-launcher.exe` بالإصدار تلقائيًا.

## ملاحظات
- ملف exe غير موقّع رقميًا، فقد تعرض Windows تحذير SmartScreen: اضغط "More info" ثم "Run anyway".
- التحديثات: ولّد `latest.json` بالأداة `tools/make_update_manifest.py` مع `--windows-url` برابط الـ exe.

## تشخيص حساب Microsoft
`xlop-launcher.exe ms-check` (أو `py -3 xlop-launcher-script.pyw ms-check`) يُظهر أين تتوقف سلسلة الدخول. إن نجحت المراحل الأربع
الأولى وفشل «Minecraft login» فالتسجيل سليم وتنتظر موافقة Mojang على المعرّف.
