# xlop launcher - Windows entry point. Start it with START-HERE.bat (or double-click this file).
# NOTE: no "#!" line on purpose - the Python launcher would try to run whatever it names.
import os
import sys
import traceback

FROZEN = getattr(sys, "frozen", False)
HERE = os.path.dirname(sys.executable) if FROZEN else os.path.dirname(os.path.abspath(__file__))
if not FROZEN:
    sys.path.insert(0, HERE)
LOGDIR = os.path.join(os.environ.get("APPDATA") or HERE, "xlop-launcher")
LOG = os.path.join(LOGDIR, "launcher.log")


TRACE = os.path.join(LOGDIR, "startup.log")


def _trace(msg):
    """Append a timestamped line to startup.log (never raises)."""
    try:
        import time
        os.makedirs(LOGDIR, exist_ok=True)
        if os.path.isfile(TRACE) and os.path.getsize(TRACE) > 200000:
            os.remove(TRACE)
        with open(TRACE, "a", encoding="utf-8") as fh:
            fh.write("%s  %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def _fatal(text):
    """Message box that works even when Tk is missing."""
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, text, "xlop launcher", 0x10)
    except Exception:
        pass


def _fix_streams():
    """pythonw / windowed exe have no console: send print() and errors to a log file."""
    if sys.stdout is None or sys.stderr is None:
        os.makedirs(LOGDIR, exist_ok=True)
        fh = open(LOG, "a", encoding="utf-8", buffering=1)
        if sys.stdout is None:
            sys.stdout = fh
        if sys.stderr is None:
            sys.stderr = fh


def main():
    _trace("python %s | %s | args=%r | from=%s" % (sys.version.split()[0], sys.executable, sys.argv[1:], HERE))
    if not os.path.isdir(os.path.join(HERE, "xlop")) and not FROZEN:
        _fatal("The 'xlop' folder is missing next to this file:\n%s\n\n"
               "If you opened this from inside the .zip, extract the whole zip first "
               "(right-click > Extract All).\n\n"
               "مجلد xlop غير موجود بجوار هذا الملف. فُكّ ضغط الملف كاملًا أولًا." % HERE)
        return 1
    gui_mode = not sys.argv[1:]
    if sys.version_info < (3, 8):
        _fatal("xlop launcher needs Python 3.8 or newer.\nDownload: https://www.python.org/downloads/windows/")
        return 1
    if gui_mode:
        try:
            import tkinter  # noqa: F401
        except ImportError:
            _fatal("Tkinter is missing from this Python.\n"
                   "Re-run the Python installer > Modify > tick 'tcl/tk and IDLE'.\n"
                   "(Python from python.org includes it.)\n\n"
                   "Tkinter غير موجود في هذا البايثون. أعد تثبيت Python من python.org مع خيار tcl/tk.")
            return 1
    from xlop.cli import main as run
    _trace("modules imported, starting")
    code = run(sys.argv[1:])
    _trace("exited normally, code=%r" % (code,))
    return code


def start():
    _fix_streams()
    try:
        code = main()
    except SystemExit as exc:
        code = exc.code
    except BaseException:
        os.makedirs(LOGDIR, exist_ok=True)
        with open(LOG, "a", encoding="utf-8") as fh:
            fh.write(traceback.format_exc() + "\n")
        _trace("CRASH: " + traceback.format_exc().strip().splitlines()[-1])
        _fatal("xlop launcher crashed.\nDetails were saved to:\n%s\n\nحدث خطأ غير متوقع. التفاصيل في الملف أعلاه." % LOG)
        code = 1
    sys.exit(code)


if __name__ == "__main__":
    start()
