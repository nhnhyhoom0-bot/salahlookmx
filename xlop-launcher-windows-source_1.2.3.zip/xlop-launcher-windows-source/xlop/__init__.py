"""xlop launcher - a Minecraft: Java Edition launcher."""
VERSION = "1.2.3"
APP_NAME = "xlop launcher"
