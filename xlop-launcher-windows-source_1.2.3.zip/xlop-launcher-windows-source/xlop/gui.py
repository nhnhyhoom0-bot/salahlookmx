"""GTK 3 interface for xlop launcher."""
import os
import subprocess
import threading
import time
import traceback
import webbrowser

import cairo
import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, GdkPixbuf, GLib, Gtk  # noqa: E402

from . import APP_NAME, VERSION, skins, urls  # noqa: E402
from . import update as updater  # noqa: E402
from .accounts import (ELYBY, MICROSOFT, OFFLINE, TYPE_LABELS, AccountStore, AuthError,  # noqa: E402
                       MicrosoftAuth, NotConfigured, TwoFactorRequired, ely_login,
                       microsoft_client_id, microsoft_ensure_fresh, new_offline_account)
from .game import GameError, launch, list_versions, load_manifest  # noqa: E402
from .net import NetError  # noqa: E402
from .paths import Config  # noqa: E402

ERRORS = (GameError, AuthError, NetError, skins.SkinError, OSError)

MS_NOT_READY = ("تسجيل الدخول بحساب Microsoft يتطلب معرّف تطبيق معتمد من Mojang، وهذا الإصدار من "
                "اللانشر لا يحتوي واحدًا بعد.\n\nمطوّر اللانشر يضعه مرة واحدة (التفاصيل في README)، "
                "وبعدها يعمل تسجيل الدخول للجميع بدون أي خطوة إضافية.\n\n"
                "يمكنك الآن استخدام الحساب الأوفلاين أو حساب Ely.by.")

CSS = b"""
.xlop-title { font-size: 26px; font-weight: bold; }
.xlop-sub { opacity: 0.7; }
.xlop-play { font-size: 18px; font-weight: bold; padding: 10px 28px; }
.xlop-update { background-color: rgba(53,132,228,0.18); padding: 8px 12px; border-radius: 6px; }
"""


def ui(fn, *args):
    """Run fn(*args) on the GTK main thread."""
    def run():
        fn(*args)
        return False
    GLib.idle_add(run)


def margins(widget, n):
    widget.set_margin_start(n)
    widget.set_margin_end(n)
    widget.set_margin_top(n)
    widget.set_margin_bottom(n)


class XlopWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title=APP_NAME)
        self.cfg = Config()
        self.store = AccountStore()
        self.manifest = None
        self.mode = "idle"                 # idle | installing | running
        self.proc = None
        self.pending_skin = None           # (png, w, h, rgba)
        self.preview = None
        self.ms_cancel = False
        self.ms_dialog = None
        self.update_info = None
        self._loading = True
        self.set_default_size(980, 640)
        self.set_icon_name("xlop-launcher")

        css = Gtk.CssProvider()
        css.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        hb = Gtk.HeaderBar()
        hb.set_show_close_button(True)
        hb.set_title(APP_NAME)
        hb.set_subtitle("v" + VERSION)
        self.set_titlebar(hb)

        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        side = Gtk.StackSidebar()
        side.set_stack(self.stack)
        side.set_size_request(170, -1)
        self.stack.add_titled(self._page_play(), "play", "اللعب")
        self.stack.add_titled(self._page_accounts(), "accounts", "الحسابات")
        self.stack.add_titled(self._page_skins(), "skins", "السكنات")
        self.stack.add_titled(self._page_settings(), "settings", "الإعدادات")
        self.stack.add_titled(self._page_log(), "log", "السجل")
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        box.pack_start(side, False, False, 0)
        box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL), False, False, 0)
        box.pack_start(self.stack, True, True, 0)
        self.add(box)

        self._loading = False
        self.connect("destroy", self.on_destroy)
        self._refresh_accounts()
        self._fill_versions()
        threading.Thread(target=self._load_manifest, daemon=True).start()
        self._maybe_check_updates()

    # ------------------------------------------------------------------ helpers
    def error(self, text, title="حدث خطأ"):
        dlg = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.ERROR,
                                buttons=Gtk.ButtonsType.CLOSE, text=title)
        dlg.format_secondary_text(str(text))
        dlg.run()
        dlg.destroy()

    def info(self, text):
        dlg = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.INFO,
                                buttons=Gtk.ButtonsType.CLOSE, text=text)
        dlg.run()
        dlg.destroy()

    def ask(self, title, fields, text=None):
        """fields: [(label, secret, default)] -> list of strings, or None if cancelled."""
        dlg = Gtk.Dialog(title=title, transient_for=self, modal=True)
        dlg.add_button("إلغاء", Gtk.ResponseType.CANCEL)
        dlg.add_button("موافق", Gtk.ResponseType.OK)
        dlg.set_default_response(Gtk.ResponseType.OK)
        grid = Gtk.Grid(column_spacing=12, row_spacing=10)
        margins(grid, 16)
        row = 0
        if text:
            lbl = Gtk.Label(label=text)
            lbl.set_line_wrap(True)
            lbl.set_max_width_chars(52)
            lbl.set_xalign(0)
            grid.attach(lbl, 0, row, 2, 1)
            row += 1
        entries = []
        for label, secret, default in fields:
            name = Gtk.Label(label=label)
            name.set_xalign(0)
            entry = Gtk.Entry()
            entry.set_text(default)
            entry.set_visibility(not secret)
            entry.set_activates_default(True)
            entry.set_hexpand(True)
            grid.attach(name, 0, row, 1, 1)
            grid.attach(entry, 1, row, 1, 1)
            entries.append(entry)
            row += 1
        dlg.get_content_area().add(grid)
        dlg.show_all()
        resp = dlg.run()
        values = [e.get_text() for e in entries]
        dlg.destroy()
        return values if resp == Gtk.ResponseType.OK else None

    def show_page(self, name):
        self.stack.set_visible_child_name(name)

    # ------------------------------------------------------------------ play page
    def _page_play(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        margins(page, 28)
        self.update_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.update_bar.get_style_context().add_class("xlop-update")
        self.update_label = Gtk.Label(label="")
        self.update_label.set_xalign(0)
        now_btn = Gtk.Button.new_with_label("تحديث الآن")
        now_btn.get_style_context().add_class("suggested-action")
        now_btn.connect("clicked", self.on_update_now)
        later_btn = Gtk.Button.new_with_label("لاحقًا")
        later_btn.connect("clicked", lambda _b: self.update_bar.hide())
        self.update_bar.pack_start(self.update_label, True, True, 0)
        self.update_bar.pack_start(now_btn, False, False, 0)
        self.update_bar.pack_start(later_btn, False, False, 0)
        self.update_bar.set_no_show_all(True)
        page.pack_start(self.update_bar, False, False, 0)
        title = Gtk.Label(label="xlop launcher")
        title.get_style_context().add_class("xlop-title")
        title.set_xalign(0)
        sub = Gtk.Label(label="ماين كرافت جافا - حسابات أوفلاين، Microsoft، و Ely.by")
        sub.get_style_context().add_class("xlop-sub")
        sub.set_xalign(0)
        page.pack_start(title, False, False, 0)
        page.pack_start(sub, False, False, 8)

        grid = Gtk.Grid(column_spacing=12, row_spacing=12)
        self.acc_combo = Gtk.ComboBoxText()
        self.acc_combo.set_hexpand(True)
        self.acc_combo.connect("changed", self.on_account_changed)
        self.ver_combo = Gtk.ComboBoxText()
        self.ver_combo.set_hexpand(True)
        self.ver_combo.connect("changed", self.on_version_changed)
        for i, (text, widget) in enumerate((("الحساب", self.acc_combo), ("النسخة", self.ver_combo))):
            lbl = Gtk.Label(label=text)
            lbl.set_xalign(0)
            grid.attach(lbl, 0, i, 1, 1)
            grid.attach(widget, 1, i, 1, 1)
        page.pack_start(grid, False, False, 0)

        filt = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        self.chk_snap = Gtk.CheckButton.new_with_label("إظهار نسخ الـ Snapshot")
        self.chk_snap.set_active(self.cfg["show_snapshots"])
        self.chk_snap.connect("toggled", self.on_filter_toggled)
        self.chk_old = Gtk.CheckButton.new_with_label("إظهار نسخ Alpha / Beta القديمة")
        self.chk_old.set_active(self.cfg["show_old"])
        self.chk_old.connect("toggled", self.on_filter_toggled)
        filt.pack_start(self.chk_snap, False, False, 0)
        filt.pack_start(self.chk_old, False, False, 0)
        page.pack_start(filt, False, False, 0)

        self.play_btn = Gtk.Button.new_with_label("ابدأ اللعب")
        self.play_btn.get_style_context().add_class("suggested-action")
        self.play_btn.get_style_context().add_class("xlop-play")
        self.play_btn.set_halign(Gtk.Align.START)
        self.play_btn.connect("clicked", self.on_play)
        page.pack_start(self.play_btn, False, False, 14)

        self.progress = Gtk.ProgressBar()
        self.progress.set_show_text(True)
        page.pack_start(self.progress, False, False, 0)
        self.status = Gtk.Label(label="")
        self.status.set_xalign(0)
        self.status.set_line_wrap(True)
        page.pack_start(self.status, False, False, 0)
        return page

    def _load_manifest(self):
        try:
            manifest = load_manifest()
            ui(self._set_manifest, manifest)
        except GameError as exc:
            ui(self._set_status, str(exc))

    def _set_manifest(self, manifest):
        self.manifest = manifest
        self._fill_versions()

    def _fill_versions(self):
        self._loading = True
        self.ver_combo.remove_all()
        versions = list_versions(self.manifest, self.cfg.root, self.chk_snap.get_active(),
                                 self.chk_old.get_active())
        notes = {"snapshot": "  (Snapshot)", "old_beta": "  (Beta)", "old_alpha": "  (Alpha)",
                 "local": "  (محلية / معدّلة)"}
        for vid, typ in versions:
            self.ver_combo.append(vid, vid + notes.get(typ, ""))
        latest = ((self.manifest or {}).get("latest") or {}).get("release")
        wanted = self.cfg["selected_version"]
        ids = [v for v, _ in versions]
        self.ver_combo.set_active_id(wanted if wanted in ids else (latest if latest in ids else (ids[0] if ids else None)))
        self._loading = False
        self.on_version_changed(self.ver_combo)

    def on_filter_toggled(self, _w):
        self.cfg["show_snapshots"] = self.chk_snap.get_active()
        self.cfg["show_old"] = self.chk_old.get_active()
        self.cfg.save()
        self._fill_versions()

    def on_version_changed(self, combo):
        vid = combo.get_active_id()
        if vid and not self._loading:
            self.cfg["selected_version"] = vid
            self.cfg.save()

    def on_account_changed(self, combo):
        acc_id = combo.get_active_id()
        if acc_id and not self._loading:
            self.cfg["selected_account"] = acc_id
            self.cfg.save()
        self._update_skin_page()

    def _set_status(self, text):
        self.status.set_text(text)

    def _progress(self, text, frac):
        self.progress.set_fraction(max(0.0, min(1.0, frac)))
        self.progress.set_text(text)

    def set_mode(self, mode):
        self.mode = mode
        self.play_btn.set_label({"idle": "ابدأ اللعب", "installing": "جارٍ التجهيز…",
                                 "running": "إيقاف اللعبة"}[mode])
        self.play_btn.set_sensitive(mode != "installing")

    def on_play(self, _btn):
        if self.mode == "running":
            if self.proc:
                self.proc.terminate()
            return
        if self.mode != "idle":
            return
        acct = self.store.get(self.acc_combo.get_active_id() or "")
        vid = self.ver_combo.get_active_id()
        if not acct:
            self.show_page("accounts")
            self.info("أضف حسابًا أولًا (أوفلاين أو Microsoft أو Ely.by)")
            return
        if not vid:
            self.error("لا توجد نسخة محددة. تحقق من الاتصال بالإنترنت ثم أعد فتح اللانشر")
            return
        self.set_mode("installing")
        threading.Thread(target=self._launch_thread, args=(acct, vid), daemon=True).start()

    def _launch_thread(self, acct, vid):
        try:
            def on_start(proc):
                self.proc = proc
                ui(self.set_mode, "running")
                ui(self._set_status, "اللعبة تعمل الآن… أبقِ اللانشر مفتوحًا")

            code = launch(self.cfg, self.store, acct, vid, self.manifest,
                          progress=lambda t, f: ui(self._progress, t, f),
                          on_line=lambda ln: ui(self.log_append, ln), on_start=on_start)
            ui(self._set_status, "انتهت اللعبة (رمز الخروج %s)" % code)
            if code not in (0, -15):
                ui(self.show_page, "log")
        except ERRORS as exc:
            ui(self._set_status, "فشل: %s" % exc)
            ui(self.error, exc)
        except Exception as exc:      # keep the UI alive whatever happens
            ui(self.log_append, traceback.format_exc())
            ui(self._set_status, "خطأ غير متوقع: %s" % exc)
        finally:
            self.proc = None
            ui(self.set_mode, "idle")
            ui(self._progress, "", 0.0)

    # ------------------------------------------------------------------ accounts page
    def _page_accounts(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        margins(page, 28)
        head = Gtk.Label(label="الحسابات")
        head.get_style_context().add_class("xlop-title")
        head.set_xalign(0)
        page.pack_start(head, False, False, 0)
        self.acc_list = Gtk.ListBox()
        self.acc_list.connect("row-selected", lambda *_: self._update_skin_page())
        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.add(self.acc_list)
        frame = Gtk.Frame()
        frame.add(scroll)
        page.pack_start(frame, True, True, 0)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        for label, cb in (("+ أوفلاين", self.add_offline), ("+ Microsoft", self.add_microsoft),
                          ("+ Ely.by", self.add_ely), ("حذف المحدد", self.remove_account)):
            b = Gtk.Button.new_with_label(label)
            b.connect("clicked", lambda _b, f=cb: f())
            row.pack_start(b, False, False, 0)
        page.pack_start(row, False, False, 0)
        note = Gtk.Label(label="الحساب الأوفلاين يصلح للعب الفردي وللسيرفرات التي تسمح بغير الأصلي (online-mode=false).")
        note.set_xalign(0)
        note.set_line_wrap(True)
        note.get_style_context().add_class("xlop-sub")
        page.pack_start(note, False, False, 0)
        return page

    def _refresh_accounts(self, select=None):
        self._loading = True
        for child in self.acc_list.get_children():
            self.acc_list.remove(child)
        self.acc_combo.remove_all()
        for acc in self.store.accounts:
            text = "%s   [%s]" % (acc["name"], TYPE_LABELS[acc["type"]])
            lbl = Gtk.Label(label=text)
            lbl.set_xalign(0)
            margins(lbl, 8)
            row = Gtk.ListBoxRow()
            row.add(lbl)
            row.acc_id = acc["id"]
            self.acc_list.add(row)
            self.acc_combo.append(acc["id"], text)
        self.acc_list.show_all()
        ids = [a["id"] for a in self.store.accounts]
        want = select or self.cfg["selected_account"]
        self.acc_combo.set_active_id(want if want in ids else (ids[0] if ids else None))
        self._loading = False
        self.on_account_changed(self.acc_combo)

    def _add_account(self, acc):
        self.store.add(acc)
        self.cfg["selected_account"] = acc["id"]
        self.cfg.save()
        self._refresh_accounts(acc["id"])

    def _selected_account(self):
        row = self.acc_list.get_selected_row()
        if row is not None:
            return self.store.get(row.acc_id)
        return self.store.get(self.acc_combo.get_active_id() or "")

    def add_offline(self):
        vals = self.ask("حساب أوفلاين", [("اسم اللاعب", False, "")],
                        text="اكتب أي اسم (حتى 16 حرفًا إنجليزيًا/أرقام/_).")
        if vals:
            try:
                self._add_account(new_offline_account(vals[0]))
            except AuthError as exc:
                self.error(exc)

    def add_ely(self):
        user = pw = ""
        need_totp = False
        while True:
            fields = [("المستخدم / البريد", False, user), ("كلمة المرور", True, pw)]
            text = "سجّل الدخول بحساب Ely.by (اسم المستخدم أو البريد)."
            if need_totp:
                fields.append(("رمز المصادقة الثنائية", False, ""))
                text = "الحساب محمي بالمصادقة الثنائية. أدخل الرمز الحالي من تطبيق المصادقة."
            vals = self.ask("حساب Ely.by", fields, text=text)
            if not vals:
                return
            user, pw = vals[0].strip(), vals[1]
            try:
                self._add_account(ely_login(user, pw, vals[2] if need_totp else None))
                return
            except TwoFactorRequired:
                need_totp = True
            except (AuthError, NetError) as exc:
                self.error(exc)
                return

    def add_microsoft(self):
        if self.ms_dialog is not None:
            return
        client_id = microsoft_client_id(self.cfg)
        if not client_id:
            self.error(MS_NOT_READY, "حساب Microsoft غير مفعّل بعد")
            return
        self.ms_cancel = False
        threading.Thread(target=self._ms_thread, args=(client_id,), daemon=True).start()

    def _ms_thread(self, client_id):
        try:
            auth = MicrosoftAuth(client_id)
            info = auth.begin()
            ui(self._ms_show_code, info)
            tokens = auth.poll(info, cancelled=lambda: self.ms_cancel)
            ui(self._ms_waiting, "تم التحقق من الرمز… جارٍ إكمال تسجيل الدخول")
            acc = auth.finish(tokens)
            ui(self._ms_close)
            ui(self._add_account, acc)
            ui(self._set_status, "تمت إضافة حساب Microsoft: %s" % acc["name"])
            ui(self.show_page, "play")
        except NotConfigured:
            ui(self._ms_close)
            ui(self.error, MS_NOT_READY, "حساب Microsoft غير مفعّل بعد")
        except ERRORS as exc:
            ui(self._ms_close)
            if not self.ms_cancel:
                ui(self.error, exc, "فشل تسجيل الدخول بحساب Microsoft")

    def _ms_show_code(self, info):
        """Dialog: 1) open page  2) type this code  3) sign in. Closes itself when done."""
        dlg = Gtk.Dialog(title="تسجيل الدخول بحساب Microsoft", transient_for=self)
        dlg.add_button("إلغاء", Gtk.ResponseType.CANCEL)
        box = dlg.get_content_area()
        margins(box, 22)
        box.set_spacing(12)
        steps = Gtk.Label(label="١) افتح صفحة Microsoft أدناه\n٢) أدخل هذا الرمز في الصفحة\n"
                                "٣) سجّل الدخول بحسابك ووافق — وسيكتمل الدخول هنا تلقائيًا")
        steps.set_xalign(0)
        code = Gtk.Label()
        code.set_markup("<span size='xx-large' weight='bold' letter_spacing='4096'>%s</span>"
                        % GLib.markup_escape_text(info["user_code"]))
        code.set_selectable(True)
        url = Gtk.Label(label=info["verification_uri"])
        url.set_selectable(True)
        buttons = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        buttons.set_halign(Gtk.Align.CENTER)
        open_btn = Gtk.Button.new_with_label("فتح صفحة Microsoft")
        open_btn.get_style_context().add_class("suggested-action")
        open_btn.connect("clicked", lambda _b: webbrowser.open(info["verification_uri"]))
        copy_btn = Gtk.Button.new_with_label("نسخ الرمز")
        copy_btn.connect("clicked", lambda _b: Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD).set_text(info["user_code"], -1))
        buttons.pack_start(open_btn, False, False, 0)
        buttons.pack_start(copy_btn, False, False, 0)
        wait_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        wait_row.set_halign(Gtk.Align.CENTER)
        spinner = Gtk.Spinner()
        spinner.start()
        self.ms_wait = Gtk.Label(label="")
        wait_row.pack_start(spinner, False, False, 0)
        wait_row.pack_start(self.ms_wait, False, False, 0)
        for w in (steps, code, url, buttons, wait_row):
            box.pack_start(w, False, False, 0)
        dlg.connect("response", lambda d, r: setattr(self, "ms_cancel", True))
        dlg.show_all()
        self.ms_dialog = dlg
        self.ms_deadline = GLib.get_monotonic_time() / 1e6 + int(info.get("expires_in", 900)) \
            if hasattr(GLib, "get_monotonic_time") else None
        self._ms_tick()
        GLib.timeout_add_seconds(1, self._ms_tick)
        webbrowser.open(info["verification_uri"])

    def _ms_waiting(self, text):
        if self.ms_dialog is not None:
            self.ms_wait.set_text(text)
            self.ms_deadline = None

    def _ms_tick(self):
        """Update the countdown label; returning True keeps the timer alive."""
        if self.ms_dialog is None:
            return False
        if getattr(self, "ms_deadline", None):
            left = max(0, int(self.ms_deadline - GLib.get_monotonic_time() / 1e6))
            self.ms_wait.set_text("بانتظار إدخال الرمز… (تنتهي صلاحيته بعد %d:%02d)" % (left // 60, left % 60))
        return True

    def _ms_close(self):
        if self.ms_dialog is not None:
            self.ms_dialog.destroy()
            self.ms_dialog = None

    def remove_account(self):
        acc = self._selected_account()
        if acc:
            self.store.remove(acc["id"])
            self._refresh_accounts()

    # ------------------------------------------------------------------ skins page
    def _page_skins(self):
        page = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=24)
        margins(page, 28)
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.preview_area = Gtk.DrawingArea()
        self.preview_area.set_size_request(160, 320)
        self.preview_area.connect("draw", self.on_draw_preview)
        frame = Gtk.Frame()
        frame.add(self.preview_area)
        left.pack_start(frame, False, False, 0)
        page.pack_start(left, False, False, 0)

        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        head = Gtk.Label(label="السكنات")
        head.get_style_context().add_class("xlop-title")
        head.set_xalign(0)
        self.skin_target = Gtk.Label(label="")
        self.skin_target.set_xalign(0)
        self.skin_target.set_line_wrap(True)
        right.pack_start(head, False, False, 0)
        right.pack_start(self.skin_target, False, False, 0)

        pick = Gtk.Button.new_with_label("اختيار صورة سكن من جهازك…")
        pick.connect("clicked", lambda _b: self.pick_skin())
        right.pack_start(pick, False, False, 0)

        fetch = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.skin_name = Gtk.Entry()
        self.skin_name.set_placeholder_text("أو اكتب اسم لاعب أصلي لجلب سكنه")
        self.skin_name.set_hexpand(True)
        fb = Gtk.Button.new_with_label("جلب")
        fb.connect("clicked", lambda _b: self.fetch_skin())
        fetch.pack_start(self.skin_name, True, True, 0)
        fetch.pack_start(fb, False, False, 0)
        right.pack_start(fetch, False, False, 0)

        self.skin_model = Gtk.ComboBoxText()
        for key, text in (("auto", "الشكل: تلقائي"), ("classic", "الشكل: كلاسيك (Steve)"), ("slim", "الشكل: نحيف (Alex)")):
            self.skin_model.append(key, text)
        self.skin_model.set_active_id("auto")
        self.skin_model.connect("changed", lambda _c: self._refresh_preview_model())
        right.pack_start(self.skin_model, False, False, 0)

        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        apply_btn = Gtk.Button.new_with_label("تطبيق السكن على الحساب")
        apply_btn.get_style_context().add_class("suggested-action")
        apply_btn.connect("clicked", lambda _b: self.apply_skin())
        rm_btn = Gtk.Button.new_with_label("إزالة السكن")
        rm_btn.connect("clicked", lambda _b: self.remove_skin())
        row.pack_start(apply_btn, False, False, 0)
        row.pack_start(rm_btn, False, False, 0)
        right.pack_start(row, False, False, 0)

        self.skin_note = Gtk.Label(label="")
        self.skin_note.set_xalign(0)
        self.skin_note.set_line_wrap(True)
        self.skin_note.set_max_width_chars(60)
        self.skin_note.get_style_context().add_class("xlop-sub")
        right.pack_start(self.skin_note, False, False, 0)
        page.pack_start(right, True, True, 0)
        return page

    def _update_skin_page(self):
        if not hasattr(self, "skin_target"):
            return
        acc = self._selected_account()
        self.pending_skin = None
        self.preview = None
        if not acc:
            self.skin_target.set_text("لا يوجد حساب محدد. أضف حسابًا أولًا.")
            self.preview_area.queue_draw()
            return
        self.skin_target.set_text("الحساب: %s   [%s]" % (acc["name"], TYPE_LABELS[acc["type"]]))
        notes = {
            OFFLINE: "للحساب الأوفلاين: يُحفظ السكن ويُعرض داخل اللعبة (النسخ 1.7.2 وما بعدها) عبر خادم محلي عند التشغيل.",
            MICROSOFT: "لحساب Microsoft: يُرفع السكن إلى حسابك الأصلي مباشرة ويظهر لكل اللاعبين.",
            ELYBY: "لحساب Ely.by: تُدار السكنات من موقع Ely.by (ارفع السكن هناك وسيظهر تلقائيًا).",
        }
        self.skin_note.set_text(notes[acc["type"]])
        if acc["type"] == OFFLINE and acc.get("skin_path") and os.path.isfile(acc["skin_path"]):
            try:
                with open(acc["skin_path"], "rb") as fh:
                    self._set_pending(fh.read(), acc.get("skin_model", "auto"))
            except (skins.SkinError, OSError):
                pass
        self.preview_area.queue_draw()

    def _set_pending(self, data, model=None):
        png, w, h, rgba = skins.normalize_skin(data)
        self.pending_skin = (png, w, h, rgba)
        if model:
            self.skin_model.set_active_id(model)
        self._refresh_preview_model()

    def _refresh_preview_model(self):
        if self.pending_skin:
            png, w, h, rgba = self.pending_skin
            model = skins.resolve_model(self.skin_model.get_active_id() or "auto", w, h, rgba)
            self.preview = skins.preview_rgba(w, h, rgba, model)
            self.preview_area.queue_draw()

    def pick_skin(self):
        dlg = Gtk.FileChooserDialog(title="اختر صورة السكن", transient_for=self, action=Gtk.FileChooserAction.OPEN)
        dlg.add_button("إلغاء", Gtk.ResponseType.CANCEL)
        dlg.add_button("فتح", Gtk.ResponseType.OK)
        flt = Gtk.FileFilter()
        flt.set_name("الصور")
        flt.add_pixbuf_formats()
        dlg.add_filter(flt)
        path = dlg.get_filename() if dlg.run() == Gtk.ResponseType.OK else None
        dlg.destroy()
        if not path:
            return
        try:
            with open(path, "rb") as fh:
                data = fh.read()
            try:
                self._set_pending(data)
            except skins.SkinError:
                if data[:8] == skins.PNG_SIG:
                    raise
                pix = GdkPixbuf.Pixbuf.new_from_file(path)           # jpg/bmp/webp -> png
                ok, buf = pix.save_to_bufferv("png", [], [])
                self._set_pending(bytes(buf))
        except (skins.SkinError, OSError, GLib.Error) as exc:
            self.error(getattr(exc, "message", exc), "تعذّر قراءة السكن")

    def fetch_skin(self):
        name = self.skin_name.get_text().strip()
        if not name:
            return
        self.skin_note.set_text("جارٍ جلب السكن…")

        def work():
            try:
                png, model = skins.fetch_skin_by_name(name)
                ui(self._fetched, png, model)
            except ERRORS as exc:
                ui(self.error, exc, "تعذّر جلب السكن")
        threading.Thread(target=work, daemon=True).start()

    def _fetched(self, png, model):
        try:
            self._set_pending(png, model)
            self.skin_note.set_text("تم جلب السكن. اضغط «تطبيق السكن على الحساب» لاستخدامه.")
        except skins.SkinError as exc:
            self.error(exc)

    def apply_skin(self):
        acc = self._selected_account()
        if not acc:
            return
        if acc["type"] == ELYBY:
            webbrowser.open(urls.ELY_SKINS_PAGE)
            self.info("تُدار سكنات Ely.by من الموقع. فتحتُ صفحة السكنات، ارفع السكن هناك وسيظهر في اللعبة.")
            return
        if not self.pending_skin:
            self.error("اختر صورة سكن أولًا")
            return
        png, w, h, rgba = self.pending_skin
        wanted = self.skin_model.get_active_id() or "auto"
        if acc["type"] == OFFLINE:
            acc["skin_path"] = skins.save_account_skin(acc["id"], png)
            acc["skin_model"] = wanted
            self.store.save()
            self.info("تم حفظ السكن. سيظهر عند تشغيل اللعبة (النسخ 1.7.2 وما بعدها).")
            return
        model = skins.resolve_model(wanted, w, h, rgba)
        self.skin_note.set_text("جارٍ رفع السكن إلى حساب Microsoft…")

        def work():
            try:
                microsoft_ensure_fresh(acc, self.cfg, self.store)
                skins.upload_skin(acc["access_token"], png, model)
                ui(self.skin_note.set_text, "تم رفع السكن. قد يستغرق ظهوره في اللعبة دقيقة.")
            except ERRORS as exc:
                ui(self.error, exc, "فشل رفع السكن")
        threading.Thread(target=work, daemon=True).start()

    def remove_skin(self):
        acc = self._selected_account()
        if not acc:
            return
        if acc["type"] == OFFLINE:
            acc["skin_path"] = ""
            self.store.save()
            self._update_skin_page()
        elif acc["type"] == MICROSOFT:
            def work():
                try:
                    microsoft_ensure_fresh(acc, self.cfg, self.store)
                    skins.reset_skin(acc["access_token"])
                    ui(self.skin_note.set_text, "أُعيد السكن الافتراضي.")
                except ERRORS as exc:
                    ui(self.error, exc)
            threading.Thread(target=work, daemon=True).start()
        else:
            webbrowser.open(urls.ELY_SKINS_PAGE)

    def on_draw_preview(self, area, cr):
        cr.set_source_rgb(0.92, 0.93, 0.95)
        cr.paint()
        if not self.preview:
            return False
        pw, ph, rgba = self.preview
        buf = bytearray(pw * ph * 4)                      # premultiplied BGRA
        for i in range(0, len(rgba), 4):
            r, g, b, a = rgba[i:i + 4]
            buf[i], buf[i + 1], buf[i + 2], buf[i + 3] = b * a // 255, g * a // 255, r * a // 255, a
        surf = cairo.ImageSurface.create_for_data(buf, cairo.FORMAT_ARGB32, pw, ph, pw * 4)
        cr.scale(10, 10)
        cr.set_source_surface(surf, 0, 0)
        cr.get_source().set_filter(cairo.FILTER_NEAREST)
        cr.paint()
        return False

    # ------------------------------------------------------------------ settings page
    def _page_settings(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        margins(page, 28)
        head = Gtk.Label(label="الإعدادات")
        head.get_style_context().add_class("xlop-title")
        head.set_xalign(0)
        page.pack_start(head, False, False, 0)
        grid = Gtk.Grid(column_spacing=14, row_spacing=10)
        c = self.cfg
        self.s_mem = Gtk.SpinButton.new_with_range(512, 65536, 256)
        self.s_mem.set_value(c["memory_mb"])
        self.s_w = Gtk.SpinButton.new_with_range(320, 7680, 1)
        self.s_w.set_value(c["width"])
        self.s_h = Gtk.SpinButton.new_with_range(240, 4320, 1)
        self.s_h.set_value(c["height"])
        self.s_java = Gtk.Entry()
        self.s_java.set_text(c["java_path"])
        self.s_java.set_placeholder_text("فارغ = استخدام Java الرسمية من Mojang تلقائيًا")
        self.s_jvm = Gtk.Entry()
        self.s_jvm.set_text(c["jvm_args"])
        self.s_jvm.set_placeholder_text("مثال: -XX:+UseG1GC")
        self.s_root = Gtk.Entry()
        self.s_root.set_text(c["game_root"])
        self.s_root.set_placeholder_text("فارغ = ‎~/.minecraft")
        self.s_msid = Gtk.Entry()
        self.s_msid.set_text(c["ms_client_id"])
        self.s_msid.set_placeholder_text("متقدم — اتركه فارغًا (المعرّف مدمج في اللانشر)")
        self.s_iso = Gtk.CheckButton.new_with_label("مجلد لعبة مستقل لكل نسخة")
        self.s_iso.set_active(c["isolate"])
        rows = (("الذاكرة (MB)", self.s_mem), ("عرض النافذة", self.s_w), ("ارتفاع النافذة", self.s_h),
                ("مسار Java", self.s_java), ("خيارات JVM", self.s_jvm), ("مجلد اللعبة", self.s_root),
                ("Microsoft Client ID (متقدم)", self.s_msid), ("", self.s_iso))
        for i, (label, widget) in enumerate(rows):
            lbl = Gtk.Label(label=label)
            lbl.set_xalign(0)
            widget.set_hexpand(True)
            grid.attach(lbl, 0, i, 1, 1)
            grid.attach(widget, 1, i, 1, 1)
            widget.connect("toggled" if isinstance(widget, Gtk.CheckButton) else "changed", self._save_settings)
        page.pack_start(grid, False, False, 0)
        self.s_auto = Gtk.CheckButton.new_with_label("فحص التحديثات تلقائيًا عند تشغيل اللانشر")
        self.s_auto.set_active(c["auto_update"])
        self.s_auto.connect("toggled", self._save_settings)
        page.pack_start(self.s_auto, False, False, 0)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        check_btn = Gtk.Button.new_with_label("افحص التحديثات الآن")
        check_btn.connect("clicked", lambda _b: self.check_updates_now())
        row.pack_start(check_btn, False, False, 0)
        row.pack_start(Gtk.Label(label="إصدار اللانشر: %s" % VERSION), False, False, 0)
        page.pack_start(row, False, False, 0)
        return page

    def _save_settings(self, *_):
        if self._loading:
            return
        c = self.cfg
        old_root = c["game_root"]
        c["memory_mb"] = self.s_mem.get_value_as_int()
        c["width"] = self.s_w.get_value_as_int()
        c["height"] = self.s_h.get_value_as_int()
        c["java_path"] = self.s_java.get_text().strip()
        c["jvm_args"] = self.s_jvm.get_text().strip()
        c["game_root"] = os.path.expanduser(self.s_root.get_text().strip())
        c["ms_client_id"] = self.s_msid.get_text().strip()
        c["isolate"] = self.s_iso.get_active()
        c["auto_update"] = self.s_auto.get_active()
        c.save()
        if c["game_root"] != old_root:
            self._fill_versions()

    # ------------------------------------------------------------------ updates
    def _maybe_check_updates(self):
        due = time.time() - float(self.cfg["last_update_check"] or 0) > 6 * 3600
        if self.cfg["auto_update"] and updater.update_url() and due:
            threading.Thread(target=self._update_check_thread, args=(False,), daemon=True).start()

    def check_updates_now(self):
        if not updater.update_url():
            self.info("التحديثات غير مفعّلة في هذه النسخة (لا يوجد رابط تحديث).")
            return
        self._set_status("جارٍ فحص التحديثات…")
        threading.Thread(target=self._update_check_thread, args=(True,), daemon=True).start()

    def _update_check_thread(self, manual):
        try:
            info = updater.check()
            self.cfg["last_update_check"] = time.time()
            self.cfg.save()
            ui(self._update_found, info, manual)
        except updater.UpdateError as exc:
            if manual:
                ui(self.error, exc, "تعذّر فحص التحديثات")

    def _update_found(self, info, manual):
        self.update_info = info
        if info:
            self.update_label.set_text("إصدار جديد متوفر: %s  (الحالي %s)" % (info["version"], VERSION))
            self.update_bar.set_no_show_all(False)
            self.update_bar.show_all()
            self.show_page("play")
        else:
            self.update_bar.hide()
            if manual:
                self.info("أنت على آخر إصدار (%s)" % VERSION)

    def on_update_now(self, *_):
        info = self.update_info
        if not info:
            return
        if self.mode != "idle":
            self.info("أغلق اللعبة أولًا ثم حدّث اللانشر")
            return
        dlg = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.QUESTION,
                                buttons=Gtk.ButtonsType.NONE, text="تحديث xlop launcher إلى %s؟" % info["version"])
        dlg.format_secondary_text((info["notes"] + "\n\n" if info["notes"] else "") +
                                  "سيُنزَّل التحديث ويُتحقق منه، ثم يُطلب منك كلمة مرور النظام لتثبيته، "
                                  "وبعدها يُعاد تشغيل اللانشر. حساباتك وإعداداتك لا تتأثر.")
        dlg.add_button("لاحقًا", Gtk.ResponseType.CANCEL)
        dlg.add_button("تحديث", Gtk.ResponseType.ACCEPT)
        resp = dlg.run()
        dlg.destroy()
        if resp != Gtk.ResponseType.ACCEPT:
            return
        self.set_mode("installing")
        threading.Thread(target=self._update_install_thread, args=(info,), daemon=True).start()

    def _update_install_thread(self, info):
        try:
            ui(self._progress, "جارٍ تنزيل التحديث والتحقق منه…", 0.3)
            path = updater.download_update(info)
            ui(self._progress, "تثبيت التحديث (أدخل كلمة مرور النظام عند الطلب)…", 0.7)
            updater.install(path)
            ui(self._update_done, info["version"])
        except updater.UpdateError as exc:
            ui(self._set_status, "فشل التحديث")
            ui(self.error, exc, "فشل التحديث")
            ui(self.set_mode, "idle")
            ui(self._progress, "", 0.0)

    def _update_done(self, version):
        self.info("تم التحديث إلى %s. سيُعاد تشغيل اللانشر الآن." % version)
        try:
            updater.restart()
        except OSError:
            self.info("أغلق اللانشر وافتحه من جديد لإكمال التحديث.")
            self.set_mode("idle")

    # ------------------------------------------------------------------ log page
    def _page_log(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        margins(page, 20)
        self.log_view = Gtk.TextView()
        self.log_view.set_editable(False)
        self.log_view.set_monospace(True)
        self.log_view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.add(self.log_view)
        page.pack_start(scroll, True, True, 0)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        clear = Gtk.Button.new_with_label("مسح السجل")
        clear.connect("clicked", lambda _b: self.log_view.get_buffer().set_text(""))
        folder = Gtk.Button.new_with_label("فتح مجلد اللعبة")
        folder.connect("clicked", lambda _b: self.open_folder())
        row.pack_start(clear, False, False, 0)
        row.pack_start(folder, False, False, 0)
        page.pack_start(row, False, False, 0)
        return page

    def log_append(self, text):
        buf = self.log_view.get_buffer()
        buf.insert(buf.get_end_iter(), text)
        mark = buf.create_mark(None, buf.get_end_iter(), False)
        self.log_view.scroll_mark_onscreen(mark)

    def open_folder(self):
        path = self.cfg.root
        os.makedirs(path, exist_ok=True)
        try:
            subprocess.Popen(["xdg-open", path])
        except OSError:
            self.error("تعذّر فتح المجلد: %s" % path)

    def on_destroy(self, _w):
        self.ms_cancel = True
        if self.proc:
            try:
                self.proc.terminate()
            except OSError:
                pass
        Gtk.main_quit()


def run():
    GLib.set_prgname("xlop-launcher")
    GLib.set_application_name(APP_NAME)
    Gtk.Window.set_default_icon_name("xlop-launcher")
    win = XlopWindow()
    win.show_all()
    Gtk.main()
    return 0
